"""AML System v9.2 - With GUI Script Support"""
import sys,os,json,ssl,urllib.request,threading,time,math,calendar,random,string,shutil,inspect,importlib.util,hashlib,subprocess,traceback
import tkinter as tk
from tkinter import ttk,messagebox,filedialog,colorchooser
from html.parser import HTMLParser
from pathlib import Path
try:
    from PIL import Image,ImageTk
    HP=1
except:
    HP=0

BD=Path.home()/"AML_System";AD=BD/"apps";SF=BD/"settings.json"
BD.mkdir(parents=True,exist_ok=True);AD.mkdir(parents=True,exist_ok=True)

def _roots():
    r=[]
    for l,p in [("Int","/storage/emulated/0"),("Int","/sdcard"),("H",str(Path.home()))]:
        try:
            q=Path(p)
            if q.exists():
                r.append((l,q))
                if l=="Int":break
        except:pass
    return r or [("H",Path.home())]
SR=_roots();DS=SR[0][1]
AUD=(".mp3",".wav",".ogg",".m4a",".flac",".aac",".opus",".wma")
VID=(".mp4",".mkv",".avi",".mov",".webm",".3gp",".flv",".wmv",".m4v")
IMG=(".png",".jpg",".jpeg",".gif",".bmp",".webp")

_GP=None
def play_a(p):
    global _GP
    try:
        from jnius import autoclass
        stop_a();_GP=autoclass('android.media.MediaPlayer')();_GP.setDataSource(str(p));_GP.prepare();_GP.start();return True
    except:_GP=None;return False
def stop_a():
    global _GP
    if _GP:
        try:_GP.stop();_GP.release()
        except:pass
        _GP=None
def pause_a():
    if _GP:
        try:_GP.pause();return True
        except:pass
    return False
def resume_a():
    if _GP:
        try:_GP.start();return True
        except:pass
    return False
def playing():
    try:return _GP is not None and _GP.isPlaying()
    except:return False

def launch_media(p,mime="*/*"):
    try:
        from jnius import autoclass
        I=autoclass('android.content.Intent');U=autoclass('android.net.Uri');F=autoclass('java.io.File')
        act=None
        for c in("ru.iiec.pydroid3.PythonActivity","org.renpy.android.PythonActivity","org.kivy.android.PythonActivity"):
            try:act=autoclass(c).mActivity;break
            except:pass
        if act:
            i=I(I.ACTION_VIEW);i.setDataAndType(U.fromFile(F(str(p))),mime)
            i.addFlags(I.FLAG_GRANT_READ_URI_PERMISSION);i.addFlags(I.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i);return True,"OK"
    except:pass
    try:
        r=subprocess.run(["am","start","-a","android.intent.action.VIEW","-d",f"file://{p}","-t",mime,"--grant-read-uri-permission","--user","0"],capture_output=True,timeout=10)
        if r.returncode==0:return True,"OK"
    except:pass
    return False,"Cannot open"

def find_media(kind,n=500,d=4):
    exts={"audio":AUD,"video":VID,"image":IMG}.get(kind,())
    if not exts:return[]
    ints=None
    for l,r in SR:
        if "Int" in l:ints=r;break
    ints=ints or Path("/storage/emulated/0")
    res=[];seen=set()
    for s in ["Music","Movies","Videos","DCIM","Pictures","Download","Downloads",""]:
        try:
            b=ints/s
            if not b.exists():continue
            for it in b.rglob("*"):
                try:
                    if not it.is_file() or it.suffix.lower() not in exts:continue
                    if len(it.relative_to(b).parts)>d:continue
                    k=str(it.resolve())
                    if k in seen:continue
                    seen.add(k);res.append(it)
                    if len(res)>=n:return res
                except:pass
        except:pass
    return res

def find_py(n=500,d=4):
    ints=None
    for l,r in SR:
        if "Int" in l:ints=r;break
    ints=ints or Path("/storage/emulated/0")
    sd=[]
    for s in ["Download","Downloads","Documents","Scripts","Python","Projects","Pydroid",""]:
        try:
            p=ints/s
            if p.exists():sd.append(p)
        except:pass
    if BD.exists():sd.append(BD)
    res=[];seen=set()
    for b in sd:
        try:
            for it in b.rglob("*.py"):
                try:
                    if not it.is_file():continue
                    if len(it.relative_to(b).parts)>d:continue
                    k=str(it.resolve())
                    if k in seen:continue
                    seen.add(k);res.append(it)
                    if len(res)>=n:return res
                except:pass
        except:pass
    return res

def apk_install(apk):
    try:
        p=Path(apk).resolve()
        if not p.exists() or not p.name.lower().endswith(".apk"):return False,"Bad file"
        from jnius import autoclass
        I=autoclass('android.content.Intent');U=autoclass('android.net.Uri');F=autoclass('java.io.File')
        act=None
        for c in("ru.iiec.pydroid3.PythonActivity","org.renpy.android.PythonActivity","org.kivy.android.PythonActivity"):
            try:act=autoclass(c).mActivity;break
            except:pass
        if act:
            ctx=act.getApplicationContext()
            try:
                FP=autoclass('androidx.core.content.FileProvider')
                au=ctx.getPackageName()+".fileprovider"
                cu=FP.getUriForFile(ctx,au,F(str(p)))
            except:cu=U.fromFile(F(str(p)))
            i=I(I.ACTION_VIEW);i.setDataAndType(cu,"application/vnd.android.package-archive")
            i.addFlags(I.FLAG_GRANT_READ_URI_PERMISSION);i.addFlags(I.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i);return True,"OK"
    except:pass
    return False,"Cannot launch"

def find_apk(d=3):
    ints=None
    for l,r in SR:
        if "Int" in l:ints=r;break
    ints=ints or Path("/storage/emulated/0")
    res=[];seen=set()
    for s in ["Download","Downloads","Documents","Pictures","DCIM",""]:
        b=ints/s
        try:
            if not b.exists():continue
            for it in b.rglob("*.apk"):
                try:
                    k=str(it.resolve())
                    if k in seen:continue
                    seen.add(k)
                    if len(it.relative_to(b).parts)>d:continue
                    res.append(it)
                    if len(res)>=100:return res
                except:pass
        except:pass
    return res

def icon(cv,n,cx,cy,s,fg,bg=""):
    n={"music":"audio","images":"image","movies":"video","files":"folder"}.get(n,n)
    h=s/2;lw=max(1,int(s/12));lw2=max(2,int(s/8))
    if bg:cv.create_rectangle(cx-h,cy-h,cx+h,cy+h,fill=bg,outline="")
    if n=="folder":
        cv.create_rectangle(cx-h+2,cy-h/3,cx+h-2,cy+h-2,fill=fg,outline=fg)
        cv.create_rectangle(cx-h+2,cy-h/2,cx-h/3,cy-h/3,fill=fg,outline=fg)
    elif n=="menu":
        for i in range(3):
            y=cy-h/2+i*(h/2);cv.create_line(cx-h,y,cx+h,y,fill=fg,width=lw2)
    elif n=="settings":
        cv.create_oval(cx-h/2,cy-h/2,cx+h/2,cy+h/2,outline=fg,width=lw)
        cv.create_oval(cx-h/4,cy-h/4,cx+h/4,cy+h/4,outline=fg,width=lw)
    elif n=="aml_suite":
        cv.create_polygon(cx-h+2,cy-h/4,cx+h-2,cy-h/4,cx,cy-h,fill=fg,outline=fg)
        cv.create_rectangle(cx-h+2,cy-h/4,cx+h-2,cy,fill=fg,outline=fg)
    elif n=="python":
        cv.create_oval(cx-h+2,cy-h+2,cx+h-2,cy+h-2,outline=fg,width=lw)
        cv.create_text(cx,cy,text="Py",fill=fg,font=("Arial",max(8,int(s*0.4)),"bold"))
    elif n=="audio":
        cv.create_polygon(cx-h/3,cy+h/2,cx+h/3,cy+h/2,cx+h/3,cy-h/2,fill=fg,outline=fg)
    elif n=="video":
        cv.create_rectangle(cx-h+2,cy-h/2,cx+h-2,cy+h/2,outline=fg,width=lw)
        cv.create_polygon(cx-h/3,cy-h/3,cx-h/3,cy+h/3,cx+h/3,cy,fill=fg,outline=fg)
    elif n=="image":
        cv.create_rectangle(cx-h+2,cy-h+2,cx+h-2,cy+h-2,outline=fg,width=lw)
        cv.create_oval(cx-h/2,cy-h/3,cx-2,cy,fill=fg,outline=fg)
    elif n=="apk":
        cv.create_rectangle(cx-h+2,cy-h+2,cx+h-2,cy+h-2,outline=fg,width=lw)
        cv.create_line(cx-h+2,cy-h/2,cx+h-2,cy-h/2,fill=fg,width=lw)
    elif n=="browser":
        cv.create_oval(cx-h,cy-h,cx+h,cy+h,outline=fg,width=lw)
        cv.create_oval(cx-h/2,cy-h,cx+h/2,cy+h,outline=fg,width=lw)
        cv.create_line(cx-h,cy,cx+h,cy,fill=fg,width=lw)
    elif n=="notepad":
        cv.create_rectangle(cx-h+2,cy-h,cx+h-2,cy+h,outline=fg,width=lw)
        for i in range(4):
            y=cy-h+5+i*(h/2);cv.create_line(cx-h+6,y,cx+h-6,y,fill=fg,width=lw)
    elif n=="clock":
        cv.create_oval(cx-h,cy-h,cx+h,cy+h,outline=fg,width=lw)
        cv.create_line(cx,cy,cx,cy-h/2,fill=fg,width=lw2)
        cv.create_line(cx,cy,cx+h/2,cy,fill=fg,width=lw2)
    elif n=="todo":
        cv.create_line(cx-h+2,cy,cx-h/4,cy+h/2,cx+h-2,cy-h/2,fill=fg,width=lw2,capstyle="round")
    elif n=="store":
        cv.create_rectangle(cx-h+2,cy-h/3,cx+h-2,cy+h,outline=fg,width=lw)
        cv.create_arc(cx-h/2,cy-h,cx+h/2,cy-h/4,start=0,extent=180,style="arc",outline=fg,width=lw)
    else:
        cv.create_oval(cx-h+2,cy-h+2,cx+h-2,cy+h-2,fill=fg,outline=fg)

TH={"dark":{"bg":"#0a1220","fg":"#ffffff","topbar":"#1f2e45","accent":"#4a9eff","card":"#1a2535","muted":"#7a8fa8"},
    "light":{"bg":"#f5f5f5","fg":"#1f2e45","topbar":"#1f2e45","accent":"#0078d4","card":"#ffffff","muted":"#666"},
    "blue":{"bg":"#0d2137","fg":"#ffffff","topbar":"#1a3a5f","accent":"#64b5f6","card":"#1e3a5c","muted":"#8ab4f8"},
    "green":{"bg":"#0d2818","fg":"#ffffff","topbar":"#1a4d2e","accent":"#4caf50","card":"#1e5631","muted":"#81c784"},
    "purple":{"bg":"#1a0b2e","fg":"#ffffff","topbar":"#2d1b4e","accent":"#ab47bc","card":"#3d2a5c","muted":"#ba68c8"},
    "amoled":{"bg":"#000000","fg":"#ffffff","topbar":"#0a0a0a","accent":"#4a9eff","card":"#151515","muted":"#888888"}}

class Settings:
    DEF={"theme":"dark","bg_color":"","fg_color":"","accent":"","bg_image":""}
    def __init__(self):
        self.d=dict(self.DEF);self.load()
    def load(self):
        try:self.d={**self.DEF,**json.loads(SF.read_text("utf-8"))}
        except:pass
    def save(self):
        try:SF.write_text(json.dumps(self.d,indent=2),"utf-8")
        except:pass
    def get(self,k,d=None):return self.d.get(k,self.DEF.get(k,d))
    def set(self,k,v):self.d[k]=v
    def pal(self):
        p=dict(TH.get(self.d.get("theme","dark"),TH["dark"]))
        if self.d.get("bg_color"):p["bg"]=self.d["bg_color"]
        if self.d.get("accent"):p["accent"]=self.d["accent"]
        return p
    def reset(self):
        self.d=dict(self.DEF);self.save()

class Splash(tk.Tk):
    def __init__(self):
        super().__init__()
        self.overrideredirect(True);self.configure(bg="#0a1220")
        sw,sh=self.winfo_screenwidth(),self.winfo_screenheight()
        self.geometry(f"{sw}x{sh}+0+0")
        c=tk.Canvas(self,bg="#0a1220",highlightthickness=0);c.pack(fill="both",expand=True)
        cx,cy=sw//2,sh//2;u=max(12,min(sw,sh)//40)
        c.create_text(cx,cy-u*4,text="AML SYSTEM",fill="#4a9eff",font=("Arial",max(24,u*2),"bold"))
        c.create_text(cx,cy-u*2,text="Anti-Money Laundering Platform",fill="#b0b8c8",font=("Arial",max(10,u//2)))
        c.create_text(cx,cy,text="Created by",fill="#b0b8c8",font=("Arial",max(10,u//2)))
        c.create_text(cx,cy+u,text="Mohammad Ramis",fill="#ffffff",font=("Arial",max(20,u),"bold"))
        c.create_text(cx,cy+u*2,text="Version 9.2",fill="#8a9ab0",font=("Arial",max(9,u//2)))
        self.bw=min(sw//2,500);self.bx=cx-self.bw//2;self.by=cy+u*5
        c.create_rectangle(self.bx,self.by,self.bx+self.bw,self.by+6,fill="#1a2535",outline="#2a3f5f")
        self.pid=c.create_rectangle(self.bx,self.by,self.bx,self.by+6,fill="#4a9eff",outline="")
        self.c=c;self.start=time.monotonic()
        self.bind("<Escape>",lambda e:self.destroy())
        self.after(50,self._tick)
    def _tick(self):
        try:
            el=time.monotonic()-self.start;p=min(el/4.0,1.0)
            self.c.coords(self.pid,self.bx,self.by,self.bx+self.bw*p,self.by+6)
            if p>=1.0:self.destroy()
            else:self.after(50,self._tick)
        except:pass

class Notepad(tk.Toplevel):
    def __init__(self,m):
        super().__init__(m);self.title("Notepad");self.geometry("600x500")
        b=tk.Frame(self,bg="#e0e0e0");b.pack(fill="x")
        tk.Button(b,text="Open",command=self._op).pack(side="left",padx=5,pady=5)
        tk.Button(b,text="Save",command=self._sv).pack(side="left",padx=5,pady=5)
        self.t=tk.Text(self,font=("Consolas",11),wrap="word");self.t.pack(fill="both",expand=True,padx=5,pady=5)
    def _op(self):
        p=filedialog.askopenfilename(parent=self,initialdir=str(DS))
        if p:
            try:self.t.delete("1.0",tk.END);self.t.insert(tk.END,Path(p).read_text("utf-8",errors="ignore"))
            except Exception as e:messagebox.showerror("Error",str(e),parent=self)
    def _sv(self):
        p=filedialog.asksaveasfilename(parent=self,initialdir=str(DS),defaultextension=".txt")
        if p:
            try:Path(p).write_text(self.t.get("1.0",tk.END),"utf-8");messagebox.showinfo("OK","Saved",parent=self)
            except Exception as e:messagebox.showerror("Error",str(e),parent=self)

class Clock(tk.Toplevel):
    def __init__(self,m):
        super().__init__(m);self.title("Clock");self.geometry("400x250");self.configure(bg="#0a1220")
        self.tv=tk.StringVar();self.dv=tk.StringVar()
        tk.Label(self,textvariable=self.tv,bg="#0a1220",fg="#4a9eff",font=("Courier",42,"bold")).pack(pady=(40,10))
        tk.Label(self,textvariable=self.dv,bg="#0a1220",fg="#7a8fa8",font=("Arial",14)).pack()
        self._t()
    def _t(self):
        self.tv.set(time.strftime("%H:%M:%S"));self.dv.set(time.strftime("%A, %B %d, %Y"));self.after(1000,self._t)

class Todo(tk.Toplevel):
    def __init__(self,m):
        super().__init__(m);self.title("Todo");self.geometry("500x500")
        self.f=BD/"todo.json"
        try:self.tasks=json.loads(self.f.read_text("utf-8"))
        except:self.tasks=[]
        e=tk.Frame(self,pady=10);e.pack(fill="x",padx=10)
        self.en=tk.Entry(e,font=("Arial",12));self.en.pack(side="left",fill="x",expand=True)
        tk.Button(e,text="Add",bg="#28a745",fg="white",command=self._add).pack(side="left",padx=5)
        self.lb=tk.Listbox(self,font=("Arial",12));self.lb.pack(fill="both",expand=True,padx=10,pady=5)
        b=tk.Frame(self);b.pack(fill="x",padx=10,pady=10)
        tk.Button(b,text="Done",bg="#4a9eff",fg="white",command=self._dn).pack(side="left",expand=True,fill="x")
        tk.Button(b,text="Delete",bg="#dc3545",fg="white",command=self._dl).pack(side="left",expand=True,fill="x")
        self._rf()
    def _sv(self):
        try:self.f.write_text(json.dumps(self.tasks,indent=2),"utf-8")
        except:pass
    def _rf(self):
        self.lb.delete(0,tk.END)
        for t in self.tasks:self.lb.insert(tk.END,("[x] " if t.get("d") else "[ ] ")+t["t"])
    def _add(self):
        x=self.en.get().strip()
        if x:self.tasks.append({"t":x,"d":False});self.en.delete(0,tk.END);self._sv();self._rf()
    def _dn(self):
        s=self.lb.curselection()
        if s:self.tasks[s[0]]["d"]=not self.tasks[s[0]].get("d",False);self._sv();self._rf()
    def _dl(self):
        s=self.lb.curselection()
        if s:del self.tasks[s[0]];self._sv();self._rf()

class Music(tk.Toplevel):
    def __init__(self,m):
        super().__init__(m);self.title("Music");self.geometry("900x700");self.configure(bg="#0a1220")
        self.pl=[];self.ci=-1
        h=tk.Frame(self,bg="#1f2e45",pady=10);h.pack(fill="x")
        tk.Label(h,text="Music Player",bg="#1f2e45",fg="white",font=("Arial",16,"bold")).pack(side="left",padx=10)
        self.st=tk.StringVar(value="Scanning...")
        tk.Label(h,textvariable=self.st,bg="#1f2e45",fg="#7a8fa8",font=("Arial",9)).pack(side="right",padx=10)
        self.nw=tk.StringVar(value="No track")
        tk.Label(self,textvariable=self.nw,bg="#0a1220",fg="#4a9eff",font=("Arial",13,"bold")).pack(pady=10)
        c=tk.Frame(self,bg="#0a1220");c.pack(fill="x")
        tk.Button(c,text="|<",bg="#4a9eff",fg="white",command=self._pv).pack(side="left",padx=3)
        self.bp=tk.Button(c,text="Play",bg="#28a745",fg="white",width=8,command=self._tg)
        self.bp.pack(side="left",padx=3)
        tk.Button(c,text="Stop",bg="#dc3545",fg="white",command=self._sp).pack(side="left",padx=3)
        tk.Button(c,text=">|",bg="#4a9eff",fg="white",command=self._nx).pack(side="left",padx=3)
        f=tk.Frame(self);f.pack(fill="both",expand=True,padx=10,pady=10)
        self.tr=ttk.Treeview(f,columns=("n","s"),show="headings")
        self.tr.heading("n",text="Song");self.tr.heading("s",text="Size")
        self.tr.column("n",width=400);self.tr.column("s",width=100)
        self.tr.pack(fill="both",expand=True)
        self.tr.bind("<Double-1>",lambda e:self._pl_sel())
        tk.Button(self,text="Rescan",bg="#4a9eff",fg="white",command=self._sc).pack(pady=5)
        self._sc()
    def _sc(self):
        self.st.set("Scanning...")
        for i in self.tr.get_children():self.tr.delete(i)
        def w():
            fs=find_media("audio")
            self.after(0,lambda:self._pp(fs))
        threading.Thread(target=w,daemon=True).start()
    def _pp(self,fs):
        self.pl=fs
        for f in fs:
            try:self.tr.insert("","end",iid=str(f),values=(f.name,f"{f.stat().st_size/1024/1024:.1f} MB"))
            except:pass
        self.st.set(f"{len(fs)} file(s)")
    def _pl_sel(self):
        s=self.tr.selection()
        if s:
            try:
                p=Path(s[0]);self.ci=self.pl.index(p);self._pl(p)
            except:pass
    def _pl(self,p):
        self.nw.set(f"Now: {p.name}")
        self.bp.config(text="Pause",bg="#f0ad4e")
        if play_a(p):return
        launch_media(p,"audio/*")
    def _tg(self):
        if playing():pause_a();self.bp.config(text="Play",bg="#28a745")
        elif _GP:resume_a();self.bp.config(text="Pause",bg="#f0ad4e")
        elif self.ci>=0:self._pl(self.pl[self.ci])
    def _sp(self):
        stop_a();self.bp.config(text="Play",bg="#28a745");self.nw.set("Stopped")
    def _pv(self):
        if self.pl and self.ci>0:self.ci-=1;self._pl(self.pl[self.ci])
    def _nx(self):
        if self.pl and self.ci<len(self.pl)-1:self.ci+=1;self._pl(self.pl[self.ci])

class Video(tk.Toplevel):
    def __init__(self,m):
        super().__init__(m);self.title("Video");self.geometry("900x700")
        h=tk.Frame(self,bg="#1f2e45",pady=10);h.pack(fill="x")
        tk.Label(h,text="Video Player",bg="#1f2e45",fg="white",font=("Arial",16,"bold")).pack(side="left",padx=10)
        self.tr=ttk.Treeview(self,columns=("n","s"),show="headings")
        self.tr.heading("n",text="Video");self.tr.heading("s",text="Size")
        self.tr.column("n",width=400);self.tr.column("s",width=100)
        self.tr.pack(fill="both",expand=True,padx=10,pady=10)
        self.tr.bind("<Double-1>",lambda e:self._pl())
        tk.Button(self,text="Play Selected",bg="#28a745",fg="white",font=("Arial",12,"bold"),command=self._pl).pack(pady=10,ipady=6)
        self._sc()
    def _sc(self):
        for i in self.tr.get_children():self.tr.delete(i)
        def w():
            fs=find_media("video")
            self.after(0,lambda:self._pp(fs))
        threading.Thread(target=w,daemon=True).start()
    def _pp(self,fs):
        for f in fs:
            try:self.tr.insert("","end",iid=str(f),values=(f.name,f"{f.stat().st_size/1024/1024:.1f} MB"))
            except:pass
    def _pl(self):
        s=self.tr.selection()
        if s:
            try:launch_media(Path(s[0]),"video/*")
            except Exception as e:messagebox.showerror("Error",str(e),parent=self)

class ImageViewer(tk.Toplevel):
    def __init__(self,m,initial=None):
        super().__init__(m);self.title("Image Viewer");self.geometry("900x700");self.configure(bg="#0a1220")
        self.imgs=[];self.idx=0;self.z=1.0;self.r=0;self.orig=None;self.ph=None
        h=tk.Frame(self,bg="#1f2e45",pady=10);h.pack(fill="x")
        tk.Label(h,text="Image Viewer",bg="#1f2e45",fg="white",font=("Arial",14,"bold")).pack(side="left",padx=10)
        b=tk.Frame(self);b.pack(fill="x")
        tk.Button(b,text="<",command=self._pv).pack(side="left")
        tk.Button(b,text=">",command=self._nx).pack(side="left")
        tk.Button(b,text="+",command=self._zi).pack(side="left")
        tk.Button(b,text="-",command=self._zo).pack(side="left")
        self.cv=tk.Canvas(self,bg="#000",highlightthickness=0);self.cv.pack(fill="both",expand=True)
        self.cv.bind("<Configure>",lambda e:self._rd())
        self.st=tk.StringVar(value="Loading...")
        tk.Label(self,textvariable=self.st,bg="#e0e0e0",anchor="w").pack(fill="x")
        self.after(100,lambda:self._sc(initial))
    def _sc(self,ini=None):
        fs=find_media("image")
        if ini:
            try:
                p=Path(ini)
                if p in fs:fs.remove(p)
                fs.insert(0,p)
            except:pass
        self.imgs=fs
        if fs:self._ld(0)
        else:self.st.set("No images")
    def _ld(self,i):
        if not self.imgs or not(0<=i<len(self.imgs)):return
        self.idx=i;p=self.imgs[i]
        self.st.set(f"{p.name} ({i+1}/{len(self.imgs)})")
        if not HP:
            launch_media(p,"image/*");return
        try:
            img=Image.open(p)
            if img.mode not in("RGB","RGBA"):img=img.convert("RGB")
            self.orig=img;self.z=1.0;self.r=0;self._rd()
        except Exception as e:self.st.set(f"Error: {e}")
    def _rd(self):
        if not self.orig:return
        try:
            img=self.orig
            if self.r:img=img.rotate(self.r,expand=True)
            cw=max(100,self.cv.winfo_width());ch=max(100,self.cv.winfo_height())
            w,h=img.size
            if w<=0 or h<=0:return
            rt=min(cw/w,ch/h)*self.z
            img=img.resize((max(1,int(w*rt)),max(1,int(h*rt))),Image.LANCZOS)
            self.ph=ImageTk.PhotoImage(img)
            self.cv.delete("all");self.cv.create_image(cw//2,ch//2,image=self.ph,anchor="center")
        except:pass
    def _pv(self):
        if self.imgs:self._ld((self.idx-1)%len(self.imgs))
    def _nx(self):
        if self.imgs:self._ld((self.idx+1)%len(self.imgs))
    def _zi(self):self.z=min(self.z*1.3,10);self._rd()
    def _zo(self):self.z=max(self.z/1.3,0.1);self._rd()

class PythonRunner(tk.Toplevel):
    def __init__(self,m,initial=None):
        super().__init__(m);self.title("Python Runner");self.geometry("900x700");self.configure(bg="#f0f0f0")
        self.ini=initial;self.proc=None
        h=tk.Frame(self,bg="#1f2e45",pady=12);h.pack(fill="x")
        tk.Label(h,text="Python Runner",bg="#1f2e45",fg="white",font=("Arial",16,"bold")).pack(side="left",padx=10)
        self.st=tk.StringVar(value="Scanning...")
        tk.Label(h,textvariable=self.st,bg="#1f2e45",fg="#7a8fa8",font=("Arial",9)).pack(side="right",padx=10)
        pn=tk.PanedWindow(self,orient="vertical",bg="#f0f0f0",sashwidth=6);pn.pack(fill="both",expand=True,padx=5,pady=5)
        top=tk.Frame(pn,bg="#f0f0f0");pn.add(top,height=240,minsize=120)
        self.tr=ttk.Treeview(top,columns=("n","s","p"),show="headings",selectmode="browse")
        for c,w,a,l in[("n",200,"w","File"),("s",90,"center","Size"),("p",300,"w","Location")]:
            self.tr.heading(c,text=l);self.tr.column(c,width=w,anchor=a)
        vs=ttk.Scrollbar(top,orient="vertical",command=self.tr.yview)
        self.tr.configure(yscrollcommand=vs.set)
        self.tr.pack(side="left",fill="both",expand=True);vs.pack(side="right",fill="y")
        self.tr.bind("<Double-1>",lambda e:self._run_sel())
        bot=tk.LabelFrame(pn,text="Output",bg="#f0f0f0",fg="#1f2e45",font=("Arial",10,"bold"))
        pn.add(bot,minsize=140)
        self.out=tk.Text(bot,wrap="word",bg="#0a1220",fg="#d0e0d0",font=("Consolas",10),height=10)
        osb=ttk.Scrollbar(bot,orient="vertical",command=self.out.yview)
        self.out.configure(yscrollcommand=osb.set)
        self.out.pack(side="left",fill="both",expand=True);osb.pack(side="right",fill="y")
        bf=tk.Frame(self,bg="#f0f0f0",pady=6);bf.pack(fill="x",padx=5)
        tk.Button(bf,text="Rescan",bg="#4a9eff",fg="white",command=self._sc).pack(side="left",padx=3)
        tk.Button(bf,text="Browse",bg="#6c757d",fg="white",command=self._bw).pack(side="left",padx=3)
        tk.Button(bf,text="Edit",bg="#f0ad4e",fg="white",command=self._ed).pack(side="left",padx=3)
        tk.Button(bf,text="Stop",bg="#dc3545",fg="white",command=self._stop).pack(side="left",padx=3)
        tk.Button(bf,text="Clear",bg="#6c757d",fg="white",command=lambda:self.out.delete("1.0",tk.END)).pack(side="left",padx=3)
        tk.Button(bf,text="Run Console",bg="#0078d4",fg="white",font=("Arial",10,"bold"),command=self._run_console).pack(side="left",padx=3)
        tk.Button(bf,text="Run (Auto)",bg="#28a745",fg="white",font=("Arial",11,"bold"),command=self._run_sel).pack(side="left",padx=3,expand=True,fill="x")
        self.after(100,self._sc)
    def _sc(self):
        self.st.set("Scanning...")
        for i in self.tr.get_children():self.tr.delete(i)
        def w():
            fs=find_py()
            try:self.after(0,lambda:self._pp(fs))
            except:pass
        threading.Thread(target=w,daemon=True).start()
    def _pp(self,fs):
        if self.ini:
            try:
                p=Path(self.ini)
                if p in fs:fs.remove(p)
                fs.insert(0,p)
            except:pass
            self.ini=None
        for f in fs:
            try:
                pn=str(f.parent)
                if len(pn)>45:pn="..."+pn[-42:]
                gui=" [GUI]" if self._gui(f) else ""
                self.tr.insert("","end",iid=str(f),values=(f.name+gui,f"{f.stat().st_size/1024:.1f} KB",pn))
            except:pass
        self.st.set(f"{len(fs)} .py file(s)")
    def _bw(self):
        p=filedialog.askopenfilename(parent=self,initialdir=str(DS),filetypes=[("Python","*.py"),("All","*.*")])
        if not p:return
        pa=Path(p)
        if not self.tr.exists(str(pa)):
            try:self.tr.insert("","end",iid=str(pa),values=(pa.name,f"{pa.stat().st_size/1024:.1f} KB",str(pa.parent)))
            except:pass
        self.tr.selection_set(str(pa));self.tr.see(str(pa))
    def _ed(self):
        s=self.tr.selection()
        if not s:messagebox.showwarning("Warning","Select file",parent=self);return
        pa=Path(s[0])
        try:
            ed=tk.Toplevel(self);ed.title(f"Edit: {pa.name}");ed.geometry("700x550")
            tb=tk.Frame(ed,bg="#e0e0e0");tb.pack(fill="x")
            body=tk.Frame(ed);body.pack(fill="both",expand=True)
            tw=tk.Text(body,wrap="none",font=("Consolas",11),bg="#0a1220",fg="#d0e0d0",insertbackground="white")
            sb=ttk.Scrollbar(body,orient="vertical",command=tw.yview)
            tw.configure(yscrollcommand=sb.set)
            tw.pack(side="left",fill="both",expand=True);sb.pack(side="right",fill="y")
            tw.insert("1.0",pa.read_text("utf-8",errors="ignore"))
            def sv():
                try:pa.write_text(tw.get("1.0",tk.END).rstrip()+"\n","utf-8");messagebox.showinfo("OK","Saved",parent=ed)
                except Exception as e:messagebox.showerror("Error",str(e),parent=ed)
            tk.Button(tb,text="Save",bg="#28a745",fg="white",command=sv).pack(side="left",padx=5,pady=4)
            tk.Button(tb,text="Close",bg="#dc3545",fg="white",command=ed.destroy).pack(side="left",padx=5,pady=4)
        except Exception as e:messagebox.showerror("Error",str(e),parent=self)
    def _gui(self,p):
        try:
            s=p.read_text("utf-8",errors="ignore")
            return("import tkinter" in s) or ("from tkinter" in s) or ("import PyQt" in s)
        except:return False
    def _run_console(self):
        s=self.tr.selection()
        if not s:messagebox.showwarning("Warning","Select .py",parent=self);return
        pa=Path(s[0])
        if pa.exists():self._run(pa)
    def _run_sel(self):
        s=self.tr.selection()
        if not s:messagebox.showwarning("Warning","Select .py",parent=self);return
        pa=Path(s[0])
        if not pa.exists():messagebox.showerror("Error","Not found",parent=self);return
        if self._gui(pa):self._run_gui(pa)
        else:self._run(pa)
    def _exe(self):
        e=sys.executable
        if e and Path(e).exists():return e
        for c in("python3","python"):
            f=shutil.which(c)
            if f:return f
        return "python"
    def _run(self,pa):
        if self.proc and self.proc.poll() is None:
            messagebox.showwarning("Busy","Running. Stop first.",parent=self);return
        self.out.delete("1.0",tk.END)
        self.out.insert(tk.END,f"$ python {pa.name}\n{'='*60}\n")
        self.st.set(f"Running {pa.name}...")
        try:
            self.proc=subprocess.Popen([self._exe(),"-u",str(pa)],cwd=str(pa.parent),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,encoding="utf-8",errors="replace")
        except Exception as e:
            self.out.insert(tk.END,f"\nCannot start: {e}\n");self.st.set("Failed");self.proc=None;return
        pr=self.proc
        def rd():
            try:
                for ln in pr.stdout:
                    try:self.after(0,lambda l=ln:self._ap(l))
                    except:return
            except Exception as e:
                try:self.after(0,lambda:self._ap(f"\n[{e}]\n"))
                except:pass
            rc=pr.wait()
            try:self.after(0,lambda:self._fin(rc))
            except:pass
        threading.Thread(target=rd,daemon=True).start()
    def _run_gui(self,pa):
        try:
            src=pa.read_text("utf-8",errors="ignore")
            code=compile(src,str(pa),"exec")
        except SyntaxError as e:
            messagebox.showerror("Syntax Error",f"Line {e.lineno}: {e.msg}",parent=self);return
        self.out.delete("1.0",tk.END)
        self.out.insert(tk.END,f"$ GUI run: {pa.name}\n{'='*60}\n")
        self.st.set(f"Running GUI: {pa.name}")
        import builtins as _bi
        def do_run():
            try:
                g={"__name__":"__main__","__file__":str(pa),"__builtins__":_bi}
                old=os.getcwd()
                try:
                    os.chdir(str(pa.parent))
                    exec(code,g)
                finally:
                    os.chdir(old)
                self._ap(f"\n[GUI script finished]\n")
                self.st.set(f"Finished: {pa.name}")
            except SystemExit:
                self._ap(f"\n[Script exited]\n");self.st.set("Exited")
            except Exception:
                self._ap(f"\n[Error]\n{traceback.format_exc()}\n");self.st.set("Error")
        self.after(50,do_run)
    def _ap(self,t):
        try:self.out.insert(tk.END,t);self.out.see(tk.END)
        except:pass
    def _fin(self,rc):
        self._ap(f"\n{'='*60}\n[Exit code {rc}]\n")
        try:self.st.set(f"Finished ({rc})")
        except:pass
        self.proc=None
    def _stop(self):
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                try:self.proc.wait(timeout=3)
                except:self.proc.kill()
                self.st.set("Stopped")
            except Exception as e:self.st.set(f"Stop fail: {e}")
        else:self.st.set("No process")

class APKInstaller(tk.Toplevel):
    def __init__(self,m):
        super().__init__(m);self.title("APK Installer");self.geometry("900x700")
        h=tk.Frame(self,bg="#1f2e45",pady=12);h.pack(fill="x")
        tk.Label(h,text="APK Installer",bg="#1f2e45",fg="white",font=("Arial",16,"bold")).pack(side="left",padx=10)
        self.st=tk.StringVar(value="Scanning...")
        tk.Label(h,textvariable=self.st,bg="#1f2e45",fg="#7a8fa8",font=("Arial",9)).pack(side="right",padx=10)
        b=tk.Frame(self,bg="#e0e0e0");b.pack(fill="x")
        tk.Button(b,text="Rescan",bg="#4a9eff",fg="white",command=self._sc).pack(side="left",padx=5,pady=5)
        tk.Button(b,text="Browse",bg="#28a745",fg="white",command=self._bw).pack(side="left",padx=5,pady=5)
        self.tr=ttk.Treeview(self,columns=("n","s"),show="headings")
        self.tr.heading("n",text="APK");self.tr.heading("s",text="Size")
        self.tr.pack(fill="both",expand=True,padx=10,pady=10)
        self.tr.bind("<Double-1>",lambda e:self._inst())
        tk.Button(self,text="Install Selected",bg="#28a745",fg="white",font=("Arial",12,"bold"),command=self._inst).pack(fill="x",padx=10,pady=10,ipady=6)
        self._sc()
    def _sc(self):
        self.st.set("Scanning...")
        for i in self.tr.get_children():self.tr.delete(i)
        def w():
            fs=find_apk()
            self.after(0,lambda:self._pp(fs))
        threading.Thread(target=w,daemon=True).start()
    def _pp(self,fs):
        for f in fs:
            try:self.tr.insert("","end",iid=str(f),values=(f.name,f"{f.stat().st_size/1024/1024:.1f} MB"))
            except:pass
        self.st.set(f"{len(fs)} APK(s)")
    def _bw(self):
        p=filedialog.askopenfilename(parent=self,initialdir=str(DS),filetypes=[("APK","*.apk")])
        if p:self._do(Path(p))
    def _inst(self):
        s=self.tr.selection()
        if s:self._do(Path(s[0]))
    def _do(self,p):
        if not messagebox.askyesno("Install",f"Install {p.name}?",parent=self):return
        ok,msg=apk_install(p)
        if ok:messagebox.showinfo("OK",msg,parent=self)
        else:messagebox.showerror("Error",msg,parent=self)

class FileManager(tk.Toplevel):
    def __init__(self,m):
        super().__init__(m);self.title("Files");self.geometry("900x700")
        self.cp=DS;self.sel=None
        b=tk.Frame(self,bg="#e0e0e0");b.pack(fill="x")
        tk.Button(b,text="Up",command=self._up).pack(side="left",padx=3,pady=5)
        tk.Button(b,text="Refresh",command=self._rf).pack(side="left",padx=3,pady=5)
        self.pv=tk.StringVar(value=str(self.cp))
        tk.Entry(b,textvariable=self.pv).pack(side="left",fill="x",expand=True,padx=5,pady=5)
        tk.Button(b,text="Go",bg="#4a9eff",fg="white",command=lambda:self._jd(self.pv.get())).pack(side="left",padx=3)
        self.tr=ttk.Treeview(self,columns=("n","s"),show="headings")
        self.tr.heading("n",text="Name");self.tr.heading("s",text="Size")
        self.tr.pack(fill="both",expand=True,padx=5,pady=5)
        self.tr.bind("<Double-1>",self._db)
        self.st=tk.StringVar(value="Ready")
        tk.Label(self,textvariable=self.st,bg="#e0e0e0",anchor="w").pack(fill="x")
        self._rf()
    def _jd(self,p):
        try:
            pa=Path(p)
            if not pa.exists():return
            if pa.is_file():pa=pa.parent
            self.cp=pa;self._rf()
        except:pass
    def _up(self):
        if self.cp.parent!=self.cp:self.cp=self.cp.parent;self._rf()
    def _rf(self):
        for i in self.tr.get_children():self.tr.delete(i)
        self.pv.set(str(self.cp))
        try:
            es=list(self.cp.iterdir());es=[e for e in es if not e.name.startswith(".")]
            es.sort(key=lambda e:(not e.is_dir(),e.name.lower()))
            for e in es:
                try:
                    sz="" if e.is_dir() else f"{e.stat().st_size/1024:.1f} KB"
                    ic_="[DIR] " if e.is_dir() else ""
                    self.tr.insert("","end",iid=str(e),values=(ic_+e.name,sz))
                except:pass
            self.st.set(f"{len(es)} items")
        except Exception as e:self.st.set(f"Error: {e}")
    def _db(self,e):
        s=self.tr.selection()
        if not s:return
        p=Path(s[0])
        if p.is_dir():self.cp=p;self._rf()
        elif p.suffix.lower()==".py":
            py=PythonRunner(self.master,initial=str(p))
            py.after(500,lambda:(py.tr.selection_set(str(p)),py._run_sel()))
        elif p.suffix.lower()==".apk":self._do_apk(p)
        elif p.suffix.lower() in IMG:ImageViewer(self.master,initial=str(p))
        elif p.suffix.lower() in VID:launch_media(p,"video/*")
        elif p.suffix.lower() in AUD:play_a(p)
        else:self.sel=p;self.destroy()
    def _do_apk(self,p):
        if messagebox.askyesno("Install",f"Install {p.name}?",parent=self):
            ok,msg=apk_install(p)
            if ok:messagebox.showinfo("OK",msg,parent=self)
            else:messagebox.showerror("Error",msg,parent=self)

class Browser(tk.Toplevel):
    def __init__(self,m):
        super().__init__(m);self.title("Browser");self.geometry("900x700")
        t=tk.Frame(self,bg="#1f2e45",pady=10);t.pack(fill="x")
        self.uv=tk.StringVar(value="https://example.com")
        tk.Entry(t,textvariable=self.uv,font=("Arial",11)).pack(side="left",fill="x",expand=True,padx=10)
        tk.Button(t,text="Go",bg="#0078d4",fg="white",command=self._ld).pack(side="left",padx=5)
        self.st=tk.StringVar(value="Enter URL")
        tk.Label(self,textvariable=self.st,bg="#e0e0e0",anchor="w").pack(fill="x")
        self.ta=tk.Text(self,wrap="word",font=("Arial",11))
        self.ta.pack(fill="both",expand=True)
    def _ld(self):
        u=self.uv.get().strip()
        if not u:return
        if not u.startswith(("http://","https://")):u="https://"+u
        self.st.set(f"Loading {u}...");self.ta.delete("1.0",tk.END)
        def w():
            try:
                ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
                r=urllib.request.Request(u,headers={"User-Agent":"Mozilla/5.0","Accept":"text/html"})
                with urllib.request.urlopen(r,timeout=15,context=ctx) as resp:
                    ch=resp.headers.get_content_charset() or "utf-8"
                    h=resp.read().decode(ch,errors="ignore")
                p=TextExtractor();p.feed(h);txt=p.get() or "(no text)"
                self.after(0,lambda:self._sh(txt,u))
            except Exception as e:
                self.after(0,lambda:self._er(str(e)))
        threading.Thread(target=w,daemon=True).start()
    def _sh(self,t,u):
        self.ta.delete("1.0",tk.END);self.ta.insert(tk.END,t);self.st.set(f"Loaded: {u}")
    def _er(self,e):
        self.ta.delete("1.0",tk.END);self.ta.insert(tk.END,f"Error: {e}");self.st.set("Failed")

class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__();self.t=[];self.sk=False
    def handle_starttag(self,tag,attrs):
        if tag in("script","style","meta","link","noscript"):self.sk=True
        elif tag in("p","br","div","h1","h2","h3","h4","li","tr"):self.t.append("\n")
    def handle_endtag(self,tag):
        if tag in("script","style","meta","link","noscript"):self.sk=False
    def handle_data(self,d):
        if not self.sk:
            x=d.strip()
            if x:self.t.append(x+" ")
    def get(self):
        return "\n".join(l for l in("".join(self.t)).split("\n") if l.strip())

class SettingsWin(tk.Toplevel):
    def __init__(self,m,app):
        super().__init__(m);self.app=app;self.s=app.settings
        self.title("Settings");self.geometry("900x700")
        h=tk.Frame(self,bg="#1f2e45",pady=15);h.pack(fill="x")
        tk.Label(h,text="Settings",bg="#1f2e45",fg="white",font=("Arial",16,"bold")).pack()
        f=tk.LabelFrame(self,text="Theme",padx=10,pady=10);f.pack(fill="x",padx=10,pady=10)
        g=tk.Frame(f);g.pack()
        for i,(tid,cl) in enumerate(TH.items()):
            btn=tk.Frame(g,bg=cl["bg"],relief="ridge",bd=2,cursor="hand2")
            btn.grid(row=i//3,column=i%3,padx=5,pady=5)
            tk.Label(btn,text=tid.title(),bg=cl["bg"],fg=cl["fg"],font=("Arial",10,"bold"),padx=20,pady=10).pack()
            btn.bind("<Button-1>",lambda e,t=tid:self._pt(t))
        f2=tk.LabelFrame(self,text="Accent",padx=10,pady=10);f2.pack(fill="x",padx=10,pady=10)
        self.av=tk.StringVar(value=self.s.get("accent") or "#4a9eff")
        self.sw=tk.Label(f2,text="  ",bg=self.av.get(),width=6,relief="ridge");self.sw.pack(side="left",padx=5)
        tk.Button(f2,text="Pick",command=self._pa).pack(side="left",padx=3)
        tk.Button(f2,text="Clear",command=self._ca).pack(side="left",padx=3)
        bf=tk.Frame(self);bf.pack(fill="x",padx=10,pady=20)
        tk.Button(bf,text="Save",bg="#28a745",fg="white",command=self._sv).pack(side="left",expand=True,fill="x",padx=3)
        tk.Button(bf,text="Close",bg="#dc3545",fg="white",command=self.destroy).pack(side="left",expand=True,fill="x",padx=3)
    def _pt(self,t):self.s.set("theme",t);self.s.set("bg_color","");self.s.set("accent","");self.app.at()
    def _pa(self):
        c=colorchooser.askcolor(initialcolor=self.av.get(),parent=self)
        if c and c[1]:self.av.set(c[1]);self.sw.config(bg=c[1]);self.s.set("accent",c[1]);self.app.at()
    def _ca(self):self.s.set("accent","");self.app.at()
    def _sv(self):self.s.save();self.app.at();self.destroy()

class AMLApp(tk.Tk):
    def __init__(self):
        super().__init__();self.overrideredirect(True)
        self.settings=Settings();self.sw=self.winfo_screenwidth();self.sh=self.winfo_screenheight()
        self.geometry(f"{self.sw}x{self.sh}+0+0")
        self._ba()
    def _ba(self):
        for w in self.winfo_children():w.destroy()
        p=self.settings.pal();self.configure(bg=p["bg"])
        tb=tk.Frame(self,bg=p["topbar"],height=55);tb.pack(fill="x");tb.pack_propagate(False)
        mb=tk.Canvas(tb,width=36,height=36,bg=p["topbar"],highlightthickness=0,cursor="hand2");mb.pack(side="left",padx=10,pady=10)
        icon(mb,"menu",18,18,22,p["fg"]);mb.bind("<Button-1>",lambda e:self._menu())
        ti=tk.Canvas(tb,width=28,height=28,bg=p["topbar"],highlightthickness=0);ti.pack(side="left",padx=5)
        icon(ti,"aml_suite",14,14,22,p["accent"])
        tk.Label(tb,text="AML System",bg=p["topbar"],fg=p["fg"],font=("Arial",14,"bold")).pack(side="left")
        sb=tk.Canvas(tb,width=36,height=36,bg=p["topbar"],highlightthickness=0,cursor="hand2");sb.pack(side="right",padx=10,pady=10)
        icon(sb,"settings",18,18,22,p["accent"]);sb.bind("<Button-1>",lambda e:SettingsWin(self,self))
        self._grid(p)
        st=tk.Frame(self,bg=p["card"],height=30);st.pack(fill="x",side="bottom");st.pack_propagate(False)
        self.st=tk.StringVar(value="Ready")
        tk.Label(st,textvariable=self.st,bg=p["card"],fg=p["fg"],font=("Arial",9)).pack(side="left",padx=10)
        tk.Label(st,text="v9.2",bg=p["card"],fg=p["muted"],font=("Arial",9)).pack(side="right",padx=10)
    def at(self):self._ba()
    def _menu(self):
        p=self.settings.pal()
        mn=tk.Menu(self,tearoff=0,font=("Arial",11),bg=p["card"],fg=p["fg"])
        mn.add_command(label="File Manager",command=lambda:FileManager(self))
        mn.add_command(label="APK Installer",command=lambda:APKInstaller(self))
        mn.add_separator()
        mn.add_command(label="Python Runner",command=lambda:PythonRunner(self))
        mn.add_command(label="Music Player",command=lambda:Music(self))
        mn.add_command(label="Video Player",command=lambda:Video(self))
        mn.add_command(label="Image Viewer",command=lambda:ImageViewer(self))
        mn.add_separator()
        mn.add_command(label="Notepad",command=lambda:Notepad(self))
        mn.add_command(label="Clock",command=lambda:Clock(self))
        mn.add_command(label="Todo",command=lambda:Todo(self))
        mn.add_separator()
        mn.add_command(label="Browser",command=lambda:Browser(self))
        mn.add_command(label="Settings",command=lambda:SettingsWin(self,self))
        mn.add_separator()
        mn.add_command(label="Exit",command=self.destroy)
        try:mn.tk_popup(10,55)
        finally:mn.grab_release()
    def _grid(self,p):
        outer=tk.Frame(self,bg=p["bg"]);outer.pack(fill="both",expand=True)
        cv=tk.Canvas(outer,bg=p["bg"],highlightthickness=0)
        vs=ttk.Scrollbar(outer,orient="vertical",command=cv.yview)
        cv.configure(yscrollcommand=vs.set)
        cv.pack(side="left",fill="both",expand=True);vs.pack(side="right",fill="y")
        g=tk.Frame(cv,bg=p["bg"]);cv.create_window((0,0),window=g,anchor="nw")
        g.bind("<Configure>",lambda e:cv.configure(scrollregion=cv.bbox("all")))
        apps=[("python","Python Runner"),("folder","Files"),("audio","Music"),("video","Video"),
              ("image","Images"),("apk","APK"),("browser","Browser"),("notepad","Notes"),
              ("clock","Clock"),("todo","Todo"),("store","Store"),("settings","Settings")]
        cols=max(3,min(6,self.sw//140))
        tk.Label(g,text="Applications",bg=p["bg"],fg=p["muted"],font=("Arial",11,"bold"),anchor="w").grid(row=0,column=0,columnspan=cols,sticky="w",padx=10,pady=(10,5))
        for i,(aid,lbl) in enumerate(apps):
            r=(i//cols)+1;c=i%cols
            self._tile(g,aid,lbl,p,r,c)
        for c in range(cols):g.columnconfigure(c,weight=1)
    def _tile(self,par,aid,lbl,p,r,c):
        t=tk.Frame(par,bg=p["bg"],cursor="hand2");t.grid(row=r,column=c,padx=8,pady=8,sticky="nsew")
        ic=tk.Canvas(t,width=64,height=64,bg=p["card"],highlightthickness=0,cursor="hand2");ic.pack()
        icon(ic,aid,32,32,40,p["accent"],p["card"])
        lb=tk.Label(t,text=lbl,bg=p["bg"],fg=p["fg"],font=("Arial",9),wraplength=90,cursor="hand2",justify="center")
        lb.pack(pady=(4,0))
        def cl(e):self._go(aid)
        def en(e):ic.config(bg=p["accent"]);icon(ic,aid,32,32,40,p["topbar"],p["accent"]);lb.config(fg=p["accent"])
        def lv(e):ic.config(bg=p["card"]);icon(ic,aid,32,32,40,p["accent"],p["card"]);lb.config(fg=p["fg"])
        for w in(t,ic,lb):w.bind("<Button-1>",cl);w.bind("<Enter>",en);w.bind("<Leave>",lv)
    def _go(self,aid):
        try:
            if aid=="python":PythonRunner(self)
            elif aid=="folder":FileManager(self)
            elif aid=="audio":Music(self)
            elif aid=="video":Video(self)
            elif aid=="image":ImageViewer(self)
            elif aid=="apk":APKInstaller(self)
            elif aid=="browser":Browser(self)
            elif aid=="notepad":Notepad(self)
            elif aid=="clock":Clock(self)
            elif aid=="todo":Todo(self)
            elif aid=="store":APKInstaller(self)
            elif aid=="settings":SettingsWin(self,self)
        except Exception as e:messagebox.showerror("Error",f"{type(e).__name__}: {e}")

if __name__=="__main__":
    Splash().mainloop()
    app=AMLApp()
    app.mainloop()