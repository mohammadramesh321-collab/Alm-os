#!/bin/sh
exec /usr/local/bin/aml-session
